import pandas as pd
from prophet import Prophet
import matplotlib.pyplot as plt
import os

# --- ВИПРАВЛЕННЯ ШЛЯХУ ---
# Отримуємо повний шлях до папки, в якій лежить цей скрипт (priklad.py)
current_dir = os.path.dirname(os.path.abspath(__file__))

# Оскільки train.csv лежить у цій же папці, з'єднуємо шлях папки та ім'я файлу
train_path = os.path.join(current_dir, "train.csv")

print(f"Завантаження даних з: {train_path} ...")
# -------------------------

# Завантажуємо дані та розпізнаємо дати
train = pd.read_csv(train_path, parse_dates=['Date'])

# Вибираємо дані лише для першого магазину (Store = 1)
df_store = train[train['Store'] == 1].copy()

# Сортуємо за датою від найстарішої до найновішої
df_store = df_store.sort_values('Date')

# Prophet ЖОРСТКО вимагає, щоб колонки називалися 'ds' (дата) та 'y' (значення)
# Перейменовуємо наші колонки 'Date' та 'Sales'
df_prophet = df_store[['Date', 'Sales']].rename(columns={'Date': 'ds', 'Sales': 'y'})

print("Навчання моделі Prophet (це може зайняти кілька секунд)...")
# Ініціалізуємо модель. Вмикаємо річну та тижневу сезонність
m = Prophet(yearly_seasonality=True, weekly_seasonality=True, daily_seasonality=False)

# Навчаємо модель на наших історичних даних
m.fit(df_prophet)

# Створюємо дати для майбутнього прогнозу (на 30 днів вперед)
future = m.make_future_dataframe(periods=30)

print("Формування прогнозу...")
# Робимо прогноз
forecast = m.predict(future)

# Будуємо фірмовий графік Prophet
fig = m.plot(forecast, figsize=(10, 6))

# Додаємо красиві підписи 
plt.title("Прогноз продажів для Магазину №1 (Prophet)", fontsize=14, fontweight='bold')
plt.xlabel("Дата", fontsize=12)
plt.ylabel("Обсяг продажів (Sales)", fontsize=12)

# Виводимо графік на екран
print("Готово! Зробіть скріншот вікна, що відкрилося.")
plt.show()